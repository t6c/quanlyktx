/* This program contains 2 parts: (1) and (2)
   YOUR TASK IS TO COMPLETE THE PART  (2)  ONLY
 */
//(1)==============================================================
import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class BSTree {

    Node root;

    BSTree() {
        root = null;
    }

    boolean isEmpty() {
        return (root == null);
    }

    void clear() {
        root = null;
    }

    void fvisit(Node p, RandomAccessFile f) throws Exception {
        if (p != null) {
            f.writeBytes(p.info + " ");
        }
    }

    void preOrder(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }

        //if (p.info.price>=3 && p.info.price<=5)
        fvisit(p, f);
        preOrder(p.left, f);
        preOrder(p.right, f);
    }

    void inOrder(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        inOrder(p.left, f);
        fvisit(p, f);
        inOrder(p.right, f);
    }

    void postOrder(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        postOrder(p.left, f);
        postOrder(p.right, f);
        fvisit(p, f);
    }

    void breadth(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        Queue q = new Queue();
        q.enqueue(p);
        Node r;
        while (!q.isEmpty()) {
            r = q.dequeue();
            fvisit(r, f);
            if (r.left != null) {
                q.enqueue(r.left);
            }
            if (r.right != null) {
                q.enqueue(r.right);
            }
        }
    }

    void loadData(int k) //do not edit this function
    {
        String[] a = Lib.readLineToStrArray("data.txt", k);
        int[] b = Lib.readLineToIntArray("data.txt", k + 1);
        int n = a.length;
        for (int i = 0; i < n; i++) {
            insert(a[i], b[i]);
        }
    }

//===========================================================================
//(2)===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
//===========================================================================
    void f0_getInformation() {
        System.out.println("HE182325");
    }

    void insert(String xOwner, int xPrice) {
        //You should insert here statements to complete this function
        if (xOwner.charAt(1) == 'X' || xPrice > 100) {
            return;
        }
        Car x = new Car(xOwner, xPrice);
        Node newNode = new Node(x);
        if (root == null) {
            root = newNode;
            return;
        }
        Node p = root;
        while (true) {
            if (x.price < p.info.price) {
                if (p.left == null) {
                    p.left = newNode;
                    break;
                } else {
                    p = p.left;
                }
            } else if (x.price > p.info.price) {
                if (p.right == null) {
                    p.right = newNode;
                    break;
                } else {
                    p = p.right;
                }
            } else {
                break;
            }
        }
    }

    void f1(int line) throws Exception {/* You do not need to edit this function. Your task is to complete insert  function
        above only.
         */
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        breadth(root, f);
        f.writeBytes("\r\nOutput:");

        breadth(root, f);
        f.writeBytes("\r\n");
        f.close();
    }

//=============================================================
    void inOrderf2(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        inOrderf2(p.left, f);
        if (p.info.price >= 3 && p.info.price <= 50) {
            fvisit(p, f);
        }
        inOrderf2(p.right, f);
    }

    void f2(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        inOrder(root, f);
        f.writeBytes("\r\nOutput:");
//        f.writeBytes("\r\n");
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        inOrderf2(root, f);
        //------------------------------------------------------------------------------------
        f.writeBytes("\r\n");
        f.close();
    }

// f.writeBytes(" k = " + k + "\r\n");
//=============================================================
    public Node delByCopying(Node root, int x) {
        if (root == null) {
            return null;
        }
        if (root.left == null && root.right == null) {
            return null;
        }
        if (x < root.info.price) {//Find node to del at the left subtree
            root.left = delByCopying(root.left, x);
        } else if (x > root.info.price) {//Find node to del at the right subtree
            root.right = delByCopying(root.right, x);
        } else if (x == root.info.price) {
            //TH1: node to del is a leaf node
            if (root.left == null && root.right == null) {
                return null;
            }
            //TH2: Node to del only has left subtree
            if (root.left != null & root.right == null) {
                return root.left;
            }
            //TH3: Node to del only has right subtree
            if (root.left == null & root.right != null) {
                return root.right;
            }
            //TH4: Node to del has 2 children
            Node newReplaceNode = findRightMostNode(root.left);
            root.info.price = newReplaceNode.info.price;
            root.left = delByCopying(root.left, newReplaceNode.info.price);
        }
        return root;
    }

    public Node findRightMostNode(Node root) {
        if (root == null) {
            return null;
        }
        Node p = root;
        while (p.right != null) {
            p = p.right;
        }
        return p;
    }

    void postOrderf3(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        postOrderf3(p.left, lNode);
        postOrderf3(p.right, lNode);
        if (p.left != null && p.right != null
                && lNode.size() < 1
                && p.info.price >= 30
                && p.info.price <= 70) {
            lNode.add(p);
        }
    }

    void f3(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        postOrder(root, f);
        f.writeBytes("\r\nOutput:");
//        inorder2(root);
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        postOrderf3(root, lNode);
        Node newNode = lNode.get(0);
        delByCopying(root, newNode.info.price);
        //------------------------------------------------------------------------------------
        postOrder(root, f);

        f.writeBytes(
                "\r\n");
        f.close();
    }

//=============================================================
    void inOrderf4(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        inOrderf4(p.left, lNode);
        if (p.left != null
                && lNode.size() < 1
                && p.info.price >= 30
                && p.info.price <= 70) {
            lNode.add(p);
        }
        inOrderf4(p.right, lNode);

    }

    public Node findLeftMostNode(Node root) {
        if (root == null) {
            return null;
        }
        Node p = root;
        while (p.left != null) {
            p = p.left;
        }
        return p;
    }

    public Node deleteByMerging(Node root, int price) {
        if (root == null) {
            return null;
        }

        Node parent = null;
        Node current = root;

        // Tìm nút cần xóa và nút cha của nó
        while (current != null && current.info.price != price) {
            parent = current;
            if (price < current.info.price) {
                current = current.left;
            } else {
                current = current.right;
            }
        }

        // Không tìm thấy nút cần xóa
        if (current == null) {
            return root;
        }

        // Nếu nút cần xóa có một hoặc không có con
        if (current.left == null) {
            if (parent == null) {
                return current.right;
            } else if (current == parent.left) {
                parent.left = current.right;
            } else {
                parent.right = current.right;
            }
        } else if (current.right == null) {
            if (parent == null) {
                return current.left;
            } else if (current == parent.left) {
                parent.left = current.left;
            } else {
                parent.right = current.left;
            }
        } else { // Nếu nút cần xóa có cả hai con
            if (parent.left == current) {
                Node successorParent = current;
                Node successorLeft = current.left;
                Node successorRight = current.right;
                parent.left = successorLeft;
                Node bridNOde = findRightMostNode(successorLeft);
                bridNOde.right = successorRight;
            } else if (parent.right == current) {
                Node successorParent = current;
                Node successorLeft = current.left;
                Node successorRight = current.right;
                parent.right = successorRight;
                Node bridNOde = findLeftMostNode(successorRight);
                bridNOde.left = successorLeft;
            }

        }
        return root;
    }

    void f4(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        inOrder(root, f);
        f.writeBytes("\r\nOutput:");
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        inOrderf4(root, lNode);
        Node newNode = lNode.get(0);
        deleteByMerging(root, newNode.info.price);
        //-------------------+-----------------------------------------------------------------
        inOrder(root, f);
        f.writeBytes("\r\n");
        f.close();
    }

    void preOrderf5(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        if (lNode.size() < 4) {
            lNode.add(p);
        }
        preOrderf5(p.left, lNode);
        preOrderf5(p.right, lNode);

    }

    void f5(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        preOrder(root, f);
        f.writeBytes("\r\nOutput:");
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        preOrderf5(root, lNode);
        Node newNode = lNode.get(3);
        delByCopying(root, newNode.info.price);
        //-------------------+-----------------------------------------------------------------
        preOrder(root, f);
        f.writeBytes("\r\n");
        f.close();
    }

    void breadthf6(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        Queue q = new Queue();
        q.enqueue(p);
        Node r;
        while (!q.isEmpty()) {
            r = q.dequeue();
            if (p.left != null && lNode.size() < 2) {
                lNode.add(r);
            }
            if (r.left != null) {
                q.enqueue(r.left);
            }
            if (r.right != null) {
                q.enqueue(r.right);
            }
        }
    }

    void f6(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        breadth(root, f);
        f.writeBytes("\r\nOutput:");
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        breadthf6(root, lNode);
        Node newNode = lNode.get(1);
        deleteByMerging(root, newNode.info.price);
        //-------------------+-----------------------------------------------------------------
        breadth(root, f);
        f.writeBytes("\r\n");
        f.close();
    }

    void preOrderf7(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        if (p.right != null && p.info.price >= 30
                && p.info.price <= 70) {
            lNode.add(p);
        }
        preOrderf7(p.left, lNode);
        preOrderf7(p.right, lNode);

    }

    public Node rightRotate(Node root) {
        Node k = root.left;
        root.left = k.right;
        k.right = root;
        Node parent = findParent(root);
        if (parent != null) {
            if (parent.left == root) {
                parent.left = k;
            } else if (parent.right == root) {
                parent.right = k;
            }

        }
        if (parent == null) {
            this.root = k;
        }

        return k;
    }

    public Node leftRotate(Node root) {
        Node k = root.right;
        root.right = k.left;
        k.left = root;
        Node parent = findParent(root);
        if (parent != null) {
            if (parent.left == root) {
                parent.left = k;
            } else if (parent.right == root) {
                parent.right = k;
            }

        }
        if (parent == null) {
            this.root = k;
        }
        return k;
    }

    Node findParent(Node p) {
        if (p == null || p == root) {
            return null;
        }
        Node parent = null;
        Node current = root;

        // Tìm nút cha của nút p 
        while (current != null && current.info.price != p.info.price) {
            parent = current;
            if (p.info.price < current.info.price) {
                current = current.left;
            } else {
                current = current.right;
            }
        }
        return parent;
    }

    void f7(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        preOrder(root, f);
        f.writeBytes("\r\nOutput:");
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        preOrderf7(root, lNode);
        Node newNode = lNode.get(0);
        leftRotate(newNode);
        //-------------------+-----------------------------------------------------------------
        preOrder(root, f);
        f.writeBytes("\r\n");
        f.close();
    }

    void preOrderf8(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        if (p.left != null && p.info.price >= 30
                && p.info.price <= 70) {
            lNode.add(p);
        }
        preOrderf8(p.left, lNode);
        preOrderf8(p.right, lNode);

    }

    void f8(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        preOrder(root, f);
        f.writeBytes("\r\nOutput:");
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        preOrderf8(root, lNode);
        Node newNode = lNode.get(0);
        rightRotate(newNode);
        //-------------------+-----------------------------------------------------------------
        preOrder(root, f);
        f.writeBytes("\r\n");
        f.close();
    }

    void inOrderf9(Node p, List<Node> lNode) {
        if (p == null) {
            return;
        }
        inOrderf9(p.left, lNode);
        lNode.add(p);
        inOrderf9(p.right, lNode);
    }

    int findHeight(int x) {
        int height = 0;
        Node p = root;
        while (p != null) {
            if (x > p.info.price) {
                p = p.right;
                height++;
            } else if (x < p.info.price) {
                p = p.left;
                height++;
            } else if (x == p.info.price) {
                break;
            }
        }
        return height;
    }

    void f9(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        inOrder(root, f);
        f.writeBytes("\r\nOutput:");
        int heightofNode = 0;
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        inOrderf9(root, lNode);
        Node newNode = lNode.get(6);
        heightofNode = findHeight(newNode.info.price);
        System.out.println(newNode.info.price);
        //-------------------+-----------------------------------------------------------------
        f.writeBytes(" " + heightofNode);
        f.close();
        //------------------+-----------------------------------------------------------------    
    }

    public int countNode(Node root) {
        if (root == null) {
            return 0;
        }
        Node p;
        java.util.Queue<Node> myQ = new LinkedList<>();
//        Queue myQ = new Queue();
        myQ.add(root);
        int count = 0;
        while (!myQ.isEmpty()) {
            p = myQ.poll();
            count++;    //increase count;
            if (p.left != null) {
                myQ.add(p.left);  //Add cay con trai vao queue            
            }
            if (p.right != null) {
                myQ.add(p.right);//Add cay con phai vao queue            
            }
        }
        return count;
    }

    void f10(int line) throws Exception {
        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        inOrder(root, f);
        f.writeBytes("\r\nOutput:");
        int NumofNode = 0;
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        List<Node> lNode = new ArrayList<>();
        inOrderf9(root, lNode);
        Node newNode = lNode.get(4);
        NumofNode = countNode(newNode);
        //-------------------+-----------------------------------------------------------------
        f.writeBytes(" " + NumofNode);
        f.close();
    }

    int countInternalNode(Node p) {
        int count = 0;
        Queue q = new Queue();
        q.enqueue(p);
        Node r = root;
        while (!q.isEmpty()) {
            r = q.dequeue();
            if (r.left != null) {
                q.enqueue(r.left);
                count++;
            }
            if (r.right != null) {
                q.enqueue(r.right);
                count++;
            }
        }
         return count;
    }

    int f11(int line) throws FileNotFoundException, IOException, Exception {
        //count internal Node

        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f;
        f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        breadth(root, f);
        f.writeBytes("\r\nOutput:");
         int count = countInternalNode(root);
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
        
       
        return 0;

    }

    int f12(int line) throws FileNotFoundException, IOException, Exception {
        //count external Node

        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f;
        f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        breadth(root, f);
//        f.writeBytes("\r\nOutput:");
        int NumofNode = 0;
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/

        return 0;
//        -----------------------------------

    }

    int f13(int line) throws Exception {
        //count internal Node

        clear();
        loadData(line);
        String fname = "kq.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f;
        f = new RandomAccessFile(fname, "rw");
        f.writeBytes("\r\nInput :");
        breadth(root, f);
//        f.writeBytes("\r\nOutput:");
        int NumofNode = 0;
        //------------------------------------------------------------------------------------
        /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/

        return 0;

    }

}
